__version__ = '1.0'
from .MainApplication import start_module_application
""" AGIV bench module 
    Start the software by MainApplication.py: start_module_application()
"""

if __name__=="__main__":
    start_module_application()
